#include "iostream"
//#include "contactmap.H"

using namespace std;

int main()
{

  // ContactMap aContacMap; 
  //char  fileName[200] ="/home/u/nkrasno/PROJECTS/INSTANCES/PDBs/pdb1a15.gr";

 cout<<"Loading";

 // aContacMap = ContactMap();

 //aContacMap.doRead(fileName);

}
